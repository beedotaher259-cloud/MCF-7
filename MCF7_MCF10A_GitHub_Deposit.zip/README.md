# MCF-7 and MCF-10A data and Geant4 simulation outputs

This repository supports the study of cell-response measurements and 6 MeV electron transport in cell geometries and a breast tumour phantom.

- experimental/ contains the assembled run-level measurements and the provenance audit.
- statistics/ contains descriptive summaries, matched-control contrasts, and analysis code. Keep the supplied CSV beside analyze.py when reproducing the analysis. Python requires NumPy, SciPy and Matplotlib.
- simulation/ contains the repeat-run outputs, energy audit and tumour simulation source. The Geant4 settings and requirements are documented in the audit package. Build with Geant4 11.4.2 and adapt the installation paths for the local machine.
- analytical/ contains the comparison between the analytical range model and Geant4.

The experimental dose column is nominal. The 6 MeV source describes the simulation. Experimental beam attribution and assay calibration require source records. Dose quantities used for the tumour model are absorbed dose in Gy, and values labelled equivalent dose in historical filenames refer to absorbed-dose matching.
