from __future__ import annotations
import csv, math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
J_PER_MEV=1.602176634e-13
FIELD_MM=60.0
RANGE_ENERGY=np.array([0.,1.,2.,3.,4.,5.,6.])
RANGE_G_CM2=np.array([0.,0.4377,0.9802,1.514,2.037,2.547,3.048])
# NBSIR 82-2451 / NIST legacy table, "new" water CSDA values.

def read_csv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write_csv(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def range_of(E):
    E=np.asarray(E,dtype=float)
    # ESTAR-supported 1-6 MeV points; below 1 MeV, log-log extension using 1-2 MeV slope.
    p=math.log(RANGE_G_CM2[2]/RANGE_G_CM2[1],2)
    out=np.interp(E,RANGE_ENERGY,RANGE_G_CM2)
    m=E<1
    out=np.where(m,RANGE_G_CM2[1]*np.maximum(E,0)**p,out)
    return out
def energy_at_range(R):
    R=np.asarray(R,dtype=float)
    p=math.log(RANGE_G_CM2[2]/RANGE_G_CM2[1],2)
    out=np.interp(R,RANGE_G_CM2,RANGE_ENERGY)
    m=R<RANGE_G_CM2[1]
    out=np.where(m,(np.maximum(R,0)/RANGE_G_CM2[1])**(1/p),out)
    return out

def lobe(theta,phi):
    r=1.0+0.045*np.sin(3*theta+0.35)*np.cos(4*phi+0.2)+0.035*np.sin(theta)*np.sin(5*phi+0.8)+0.020*np.sin(theta)**2*np.cos(7*phi-2*theta+0.4)
    for k in range(6):
        th0=.65+.48*k; ph0=.53+2.39996322973*k
        cs=np.sin(theta)*np.sin(th0)*np.cos(phi-ph0)+np.cos(theta)*np.cos(th0)
        ang=np.arccos(np.clip(cs,-1,1)); r+=.075*np.exp(-.5*(ang/.16)**2)
    return r

def shape_scales(D):
    nt,np_ = 48,96
    mx=my=mz=0.
    for i in range(nt+1):
        th=math.pi*i/nt
        ph=np.arange(np_)*2*math.pi/np_
        rr=lobe(np.full(np_,th),ph)
        mx=max(mx,float(np.max(np.abs((D/2)*rr*np.sin(th)*np.cos(ph)))))
        my=max(my,float(np.max(np.abs((D*5/12)*rr*np.sin(th)*np.sin(ph)))))
        mz=max(mz,float(np.max(np.abs((D/3)*rr*math.cos(th)))))
    return D/2/mx,(D*5/12)/my,(D/3)/mz

def analytic_one(D, depth, tumor_mass_kg, pitch=.5, zstep=.1):
    # Same 60x60-mm uniform square source and same body/tissue nesting as the Geant4 model.
    n=int(round(FIELD_MM/pitch))
    q=-FIELD_MM/2+(np.arange(n)+.5)*pitch
    X,Y=np.meshgrid(q,q,indexing='xy'); X=X.ravel();Y=Y.ravel(); nr=X.size
    ax,ay,az=D/2,D*5/12,D/3
    sx,sy,sz=shape_scales(D)
    nsteps=int(math.ceil(2*az/zstep)); zloc=-az+(np.arange(nsteps)+.5)*(2*az/nsteps); dz=2*az/nsteps
    first=np.full(nr,nsteps,dtype=np.int32); last=np.full(nr,-1,dtype=np.int32)
    for iz,z in enumerate(zloc):
        qx=X/(ax*sx); qy=Y/(ay*sy); qz=z/(az*sz)
        rho=np.sqrt(qx*qx+qy*qy+qz*qz)
        inside=rho<=1.12
        th=np.arccos(np.clip(np.divide(qz,rho,out=np.zeros_like(rho),where=rho>0),-1,1))
        ph=np.arctan2(qy,qx)
        inside &= rho<=lobe(th,ph)
        first[inside]=np.minimum(first[inside],iz); last[inside]=iz
    hit=last>=first
    zentry=depth-az + first*dz
    chord=np.where(hit,(last-first+1)*dz,0.)
    # Breast surface and concentric interfaces along +z, at each source x,y.
    outer_term=1-X*X/50**2-Y*Y/60**2
    skin_inner_term=1-X*X/48**2-Y*Y/58**2
    adip_inner_term=1-X*X/44**2-Y*Y/54**2
    outer_front=35-35*np.sqrt(np.maximum(outer_term,0))
    skin_inner_front=35-33*np.sqrt(np.maximum(skin_inner_term,0))
    adip_inner_front=35-31*np.sqrt(np.maximum(adip_inner_term,0))
    skin_len=np.maximum(skin_inner_front-outer_front,0.)
    adip_len=np.maximum(adip_inner_front-skin_inner_front,0.)
    core_len=np.maximum(zentry-adip_inner_front,0.)
    # Densities (g/cm3) from source model material definitions, areal depth is rho * path_cm.
    rho_skin,rho_adip,rho_breast,rho_tumor=1.09,.95,.998,1.03
    upstream=(rho_skin*skin_len+rho_adip*adip_len+rho_breast*core_len)/10.
    tumor_areal=rho_tumor*chord/10.
    E_in=energy_at_range(np.maximum(RANGE_G_CM2[-1]-upstream,0.))
    R_in=range_of(E_in)
    E_out=energy_at_range(np.maximum(R_in-tumor_areal,0.))
    # Primary kinetic energy loss in target; assumes local deposition, ignoring photon/secondary escape.
    edep=np.where(hit,np.maximum(E_in-E_out,0.),0.)
    mean_edep=edep.mean()
    return {'analytic_edep_MeV_per_primary':float(mean_edep),'analytic_dose_Gy_per_primary':float(mean_edep*J_PER_MEV/float(tumor_mass_kg)),
            'ray_fraction_intersecting_tumor':float(hit.mean()),'mean_primary_energy_at_tumor_MeV_over_hit_rays':float(E_in[hit].mean()) if np.any(hit) else 0.,
            'mean_tumor_chord_mm_over_hit_rays':float(chord[hit].mean()) if np.any(hit) else 0.,'quad_pitch_mm':pitch,'quad_zstep_mm':dz,'n_rays':nr}

scenarios=read_csv(OUT/'IrregularTumor6MeV_ScenarioSummary.csv')
# evaluate two transverse quadrature spacings for deterministic integration sensitivity
analytical=[]; comparison=[]; dose_counts=[]
for s in scenarios:
    D=float(s['tumor_max_diameter_x_mm']); center=float(s['tumor_center_depth_mm']);prox=float(s['tumor_proximal_depth_mm'])
    depth_kind='center' if 'center' in s['scenario'] else 'proximal_surface'
    # The existing case matrix defines depth value as center or proximal edge; translate to center coordinate for the model.
    depth=center
    if depth_kind=='proximal_surface': depth=prox + float(s['tumor_thickness_z_mm'])/2
    current_mass=float(s['tumor_mass_kg'])
    a05=analytic_one(D,depth,current_mass,pitch=.5,zstep=.25)
    a025=analytic_one(D,depth,current_mass,pitch=.25,zstep=.25)
    qdelta=abs(a025['analytic_dose_Gy_per_primary']-a05['analytic_dose_Gy_per_primary'])/a025['analytic_dose_Gy_per_primary']*100 if a025['analytic_dose_Gy_per_primary'] else 0
    an={**a025,'scenario':s['scenario'],'tumor_mass_kg':current_mass,'tumor_center_depth_mm':depth,'tumor_proximal_depth_mm':depth-float(s['tumor_thickness_z_mm'])/2,
        'range_model':'NIST/ESTAR water mass range; density-scaled soft-tissue assumption','transverse_quadrature_relative_change_percent_vs_0p5mm':qdelta}
    analytical.append(an)
    mc=float(s['tumor_dose_Gy_per_primary']); mce=float(s['tumor_dose_SE_Gy_per_primary']); dose=float(a025['analytic_dose_Gy_per_primary'])
    comparison.append({'scenario':s['scenario'],'diameter_x_mm':D,'width_y_mm':float(s['tumor_width_y_mm']),'thickness_z_mm':float(s['tumor_thickness_z_mm']),
      'depth_definition':s['depth_interpretation'],'center_depth_mm':depth,'proximal_surface_depth_mm':depth-float(s['tumor_thickness_z_mm'])/2,
      'tumor_mass_kg':current_mass,'Geant4_histories':int(float(s['histories_total'])),'Geant4_dose_Gy_per_primary':mc,'Geant4_MC_SE_Gy_per_primary':mce,
      'Geant4_MC_relative_SE_percent':100*mce/mc,'analytical_dose_Gy_per_primary':dose,'analytical_edep_MeV_per_primary':a025['analytic_edep_MeV_per_primary'],
      'analytical_quadrature_change_percent':qdelta,'analytical_quadrature_change_Gy_per_primary':abs(dose-a05['analytic_dose_Gy_per_primary']),'discrepancy_analytical_minus_Geant4_percent':100*(dose-mc)/mc,
      'MC_statistical_uncertainty_Gy_per_primary_1SE':mce,'analytical_uncertainty':'deterministic integration sensitivity only; no MC uncertainty'})
    for k in [1.0,.658]:
      for cell_nom in [2.5,5.,10.,15.,20.,25.]:
        target=cell_nom*k
        nmc=target/mc; nan=target/dose
        dose_counts.append({'scenario':s['scenario'],'k_sensitivity':k,'nominal_cell_dose_Gy':cell_nom,'absorbed_dose_matching_target_Gy':target,
           'Geant4_source_electrons':math.ceil(nmc),'Geant4_count_SE_1sigma':nmc*(mce/mc),'analytical_source_electrons':math.ceil(nan),
           'analytical_count_quadrature_sensitivity_electrons':nan*qdelta/100,'interpretation':'k=0.658 is a sensitivity only; not a verified cell-dose correction'})

write_csv(OUT/'Analytical_Baseline_vs_Geant4.csv',comparison)
write_csv(OUT/'Analytical_Dose_Counts_k_Sensitivity.csv',dose_counts)
write_csv(OUT/'Analytical_Model_Details.csv',analytical)
write_csv(OUT/'NIST_Water_CSDA_Range_Input.csv',[{'electron_energy_MeV':e,'CSDA_range_g_cm2':r,'source':'NBSIR 82-2451 Table 1, New values; water' if e>=1 else 'Boundary condition for extrapolation below 1 MeV; not a source-table datum'} for e,r in zip(RANGE_ENERGY,RANGE_G_CM2)])
print('case,MC dose,analytic dose,discrepancy%,analytic quad change%')
for r in comparison: print(r['scenario'],f"{r['Geant4_dose_Gy_per_primary']:.4e}",f"{r['analytical_dose_Gy_per_primary']:.4e}",f"{r['discrepancy_analytical_minus_Geant4_percent']:.1f}",f"{r['analytical_quadrature_change_percent']:.2f}")

