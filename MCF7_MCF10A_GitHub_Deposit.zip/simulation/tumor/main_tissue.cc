#include "G4RunManager.hh"
#include "G4VUserDetectorConstruction.hh"
#include "G4VModularPhysicsList.hh"
#include "G4EmStandardPhysics_option4.hh"
#include "G4StepLimiterPhysics.hh"
#include "G4EmParameters.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Ellipsoid.hh"
#include "G4SubtractionSolid.hh"
#include "G4TessellatedSolid.hh"
#include "G4TriangularFacet.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4UserLimits.hh"
#include "G4ParticleGun.hh"
#include "G4Electron.hh"
#include "G4Positron.hh"
#include "G4Gamma.hh"
#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4UserEventAction.hh"
#include "G4UserSteppingAction.hh"
#include "G4UserRunAction.hh"
#include "G4Step.hh"
#include "G4Track.hh"
#include "G4Run.hh"
#include "G4Event.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4UImanager.hh"
#include "G4EmCalculator.hh"
#include "Randomize.hh"
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

namespace fs=std::filesystem;
constexpr int NB=200, NH=120;
constexpr double JPERMEV=1.602176634e-13;
struct Moment {
  double sum=0, sq=0;
  void add(double x){sum+=x;sq+=x*x;}
  double mean(long n)const{return sum/n;}
  double sd(long n)const{return n>1?std::sqrt(std::max(0.,(sq-sum*sum/n)/(n-1))):0.;}
  double se(long n)const{return n>1?std::sqrt(std::max(0.,(sq-sum*sum/n)/(n-1)/n)):0.;}
};
struct Tri { G4ThreeVector a,b,c; };
struct Voxel {double x,y,z,fraction;Moment e;};

static double lobe(double theta,double phi){
  double r=1.0 + 0.045*std::sin(3.0*theta+0.35)*std::cos(4.0*phi+0.2)
                 + 0.035*std::sin(theta)*std::sin(5.0*phi+0.8)
                 + 0.020*std::pow(std::sin(theta),2)*std::cos(7.0*phi-2.0*theta+0.4);
  for(int k=0;k<6;k++){
    double th0=.65+.48*k,ph0=.53+2.39996322973*k;
    double cs=std::sin(theta)*std::sin(th0)*std::cos(phi-ph0)+std::cos(theta)*std::cos(th0);
    double ang=std::acos(std::clamp(cs,-1.0,1.0));
    r+=.075*std::exp(-.5*std::pow(ang/.16,2));
  }
  return r;
}

struct State {
  double voxelPitch=2.0;
  double dx,dy,dz,depth,maxStep,cut,ax,ay,az,sx=1,sy=1,sz=1,tumorVol=0,tumorDensity=1.03,breastDensity=.998;
  int events,seed,nx,ny,nz;
  std::string dir;
  G4LogicalVolume *skin=nullptr,*adipose=nullptr,*breast=nullptr,*target=nullptr,*wall=nullptr;
  G4Material *skinMat=nullptr,*adiposeMat=nullptr,*softMat=nullptr,*breastMat=nullptr,*muscleMat=nullptr;
  std::vector<Tri> facets;
  Moment targetE,breastE,adiposeE,skinE,wallE,totalE,exitE,trackLength,entryCount,entryEnergy;
  double eventTarget=0,eventBreast=0,eventAdipose=0,eventSkin=0,eventWall=0,eventTotal=0,eventExit=0,eventTrack=0;
  Moment bodyInE, worldOutE, outsideDepositE, bodyResidualE, worldResidualE;
  double eventBodyIn=0, eventWorldOut=0, eventOutsideDeposit=0;
  double eventEntries=0,eventEntryEnergy=0;
  std::array<Moment,NB> depthE;
  std::array<double,NB> eventDepth{},depthMass{};
  std::array<double,NH> entryHist{},exitElectronHist{},exitPhotonHist{};
  std::array<double,3> exitCounts{},exitKinetic{};
  std::vector<Voxel> voxels;
  std::vector<double> eventVoxel;
  std::vector<int> touched;
  std::vector<char> seen;

  State(double diameter,double z,int n,int seed_,double step,double cut_,std::string path,double voxelPitch_=2.0):
    voxelPitch(voxelPitch_),dx(diameter),dy(diameter*5./6.),dz(diameter*2./3.),depth(z),maxStep(step),cut(cut_),ax(dx/2),ay(dy/2),az(dz/2),events(n),seed(seed_),nx(int(std::ceil(dx/voxelPitch))),ny(int(std::ceil(dy/voxelPitch))),nz(int(std::ceil(dz/voxelPitch))),dir(path){
    fs::create_directories(dir);
    buildMesh();
    const int q=6;
    for(int iz=0;iz<nz;iz++)for(int iy=0;iy<ny;iy++)for(int ix=0;ix<nx;ix++){
      double x=-ax+(ix+.5)*voxelPitch,y=-ay+(iy+.5)*voxelPitch,zloc=-az+(iz+.5)*voxelPitch,f=0;
      int inside=0;
      for(int a=0;a<q;a++)for(int b=0;b<q;b++)for(int c=0;c<q;c++){
        double xx=x-voxelPitch/2+(a+.5)*voxelPitch/q, yy=y-voxelPitch/2+(b+.5)*voxelPitch/q, zz=zloc-voxelPitch/2+(c+.5)*voxelPitch/q;
        if(insideTumor(xx,yy,zz))inside++;
      }
      f=double(inside)/(q*q*q);
      voxels.push_back({x,y,depth+zloc,f,{}});
    }
    eventVoxel.resize(voxels.size(),0);seen.resize(voxels.size(),0);
    for(int k=0;k<NB;k++)depthMass[k]=depthCellMass((k+.5)*.5,.5);
  }
  void buildMesh(){
    const int nt=48,np=96;
    auto point=[&](double th,double ph){
      double r=lobe(th,ph);
      return G4ThreeVector(ax*r*std::sin(th)*std::cos(ph),ay*r*std::sin(th)*std::sin(ph),az*r*std::cos(th));
    };
    std::vector<std::vector<G4ThreeVector>> rings(nt+1,std::vector<G4ThreeVector>(np));
    for(int i=0;i<=nt;i++){
      double th=pi*i/nt;
      for(int j=0;j<np;j++)rings[i][j]=point(th,2*pi*j/np);
    }
    double mx=0,my=0,mz=0;
    for(const auto&r:rings)for(const auto&p:r){mx=std::max(mx,std::abs(p.x()));my=std::max(my,std::abs(p.y()));mz=std::max(mz,std::abs(p.z()));}
    sx=ax/mx;sy=ay/my;sz=az/mz;
    for(auto&r:rings)for(auto&p:r)p=G4ThreeVector(p.x()*sx,p.y()*sy,p.z()*sz);
    auto add=[&](G4ThreeVector a,G4ThreeVector b,G4ThreeVector c){facets.push_back({a,b,c});tumorVol+=a.dot(b.cross(c))/6.0;};
    G4ThreeVector top(0,0,az),bottom(0,0,-az);
    for(int j=0;j<np;j++){
      int j1=(j+1)%np;
      add(top,rings[1][j],rings[1][j1]);
    }
    for(int i=1;i<nt-1;i++)for(int j=0;j<np;j++){
      int j1=(j+1)%np;
      auto a=rings[i][j],b=rings[i+1][j],c=rings[i+1][j1],d=rings[i][j1];
      add(a,b,c);add(a,c,d);
    }
    for(int j=0;j<np;j++){
      int j1=(j+1)%np;
      add(rings[nt-1][j],bottom,rings[nt-1][j1]);
    }
    tumorVol=std::abs(tumorVol);
  }
  bool insideTumor(double x,double y,double z)const{
    double qx=x/(ax*sx),qy=y/(ay*sy),qz=z/(az*sz);
    double rho=std::sqrt(qx*qx+qy*qy+qz*qz);
    if(rho==0)return true;
    if(rho>1.12)return false;
    double th=std::acos(std::clamp(qz/rho,-1.0,1.0));
    double ph=std::atan2(qy,qx);
    return rho<=lobe(th,ph);
  }
  double densityAt(double x,double y,double z)const{
    // Centered breast: outer ellipsoid 50 x 60 x 35 mm; 2-mm skin shell.
    double zz=z-35.0;
    bool outer=(x*x/(50.*50.)+y*y/(60.*60.)+zz*zz/(35.*35.))<=1.0;
    if(outer){
      bool inner=(x*x/(48.*48.)+y*y/(58.*58.)+zz*zz/(33.*33.))<=1.0;
      if(!inner)return 1.09;
      bool gland=(x*x/(44.*44.)+y*y/(54.*54.)+zz*zz/(31.*31.))<=1.0;
      if(!gland)return .95;
      return insideTumor(x,y,z-depth)?tumorDensity:breastDensity;
    }
    if(z>=70&&z<=100&&std::abs(x)<=100&&std::abs(y)<=100)return 1.05;
    return 0;
  }
  double depthCellMass(double zc,double th){
    const int qx=12,qy=12,qz=4;
    double sum=0;
    for(int i=0;i<qx;i++)for(int j=0;j<qy;j++)for(int k=0;k<qz;k++){
      double x=-10+(i+.5)*20/qx,y=-10+(j+.5)*20/qy,z=zc-th/2+(k+.5)*th/qz;
      sum+=densityAt(x,y,z);
    }
    double cellVol=20.*20.*th/(qx*qy*qz);
    return sum*cellVol*1e-6;
  }
  int index(double x,double y,double z){
    int ix=int(std::floor((x+ax)/voxelPitch)),iy=int(std::floor((y+ay)/voxelPitch)),iz=int(std::floor((z-depth+az)/voxelPitch));
    if(ix<0||iy<0||iz<0||ix>=nx||iy>=ny||iz>=nz)return -1;
    return (iz*ny+iy)*nx+ix;
  }
  void voxelAdd(int i,double e){if(i<0)return;if(!seen[i]){seen[i]=1;touched.push_back(i);}eventVoxel[i]+=e;}
  bool body(G4LogicalVolume*l)const{return l==skin||l==adipose||l==breast||l==target||l==wall;}
  void finishEvent(){
    targetE.add(eventTarget);breastE.add(eventBreast);adiposeE.add(eventAdipose);skinE.add(eventSkin);wallE.add(eventWall);totalE.add(eventTotal);exitE.add(eventExit);
    bodyInE.add(eventBodyIn);
    worldOutE.add(eventWorldOut);
    outsideDepositE.add(eventOutsideDeposit);
    bodyResidualE.add(eventBodyIn-eventExit-eventTotal);
    worldResidualE.add(6.0-eventTotal-eventOutsideDeposit-eventWorldOut);
    eventBodyIn=eventWorldOut=eventOutsideDeposit=0;
    trackLength.add(eventTrack);entryCount.add(eventEntries);entryEnergy.add(eventEntryEnergy);
    for(int k=0;k<NB;k++){depthE[k].add(eventDepth[k]);eventDepth[k]=0;}
    for(int i:touched){voxels[i].e.add(eventVoxel[i]);eventVoxel[i]=0;seen[i]=0;}touched.clear();
    eventTarget=eventBreast=eventAdipose=eventSkin=eventWall=eventTotal=eventExit=eventTrack=eventEntries=eventEntryEnergy=0;
  }
};

class Detector:public G4VUserDetectorConstruction{
 State&s;
public:explicit Detector(State&v):s(v){}
 G4VPhysicalVolume*Construct()override{
   auto*n=G4NistManager::Instance();
   s.skinMat=n->FindOrBuildMaterial("G4_SKIN_ICRP");
   s.adiposeMat=n->FindOrBuildMaterial("G4_ADIPOSE_TISSUE_ICRP");
   s.softMat=n->FindOrBuildMaterial("G4_TISSUE_SOFT_ICRP");
   s.muscleMat=n->FindOrBuildMaterial("G4_MUSCLE_SKELETAL_ICRP");
   if(!s.skinMat||!s.adiposeMat||!s.softMat||!s.muscleMat)G4Exception("Detector::Construct","MAT001",FatalException,"Required ICRP tissue material not found");
   s.tumorDensity=s.softMat->GetDensity()/(g/cm3);
   s.breastDensity=.40*(s.adiposeMat->GetDensity()/(g/cm3))+.60*(s.softMat->GetDensity()/(g/cm3));
   s.breastMat=new G4Material("BreastMix_40Adipose_60Soft",s.breastDensity*g/cm3,2);
   s.breastMat->AddMaterial(s.adiposeMat,.40);s.breastMat->AddMaterial(s.softMat,.60);
   auto*vac=n->FindOrBuildMaterial("G4_Galactic");
   auto*worldLV=new G4LogicalVolume(new G4Box("World",150*mm,150*mm,150*mm),vac,"World");
   auto*world=new G4PVPlacement(nullptr,{0,0,0},worldLV,"World",nullptr,false,0);
   auto*outer=new G4Ellipsoid("BreastOuter",50*mm,60*mm,35*mm);
   auto*innerForSkin=new G4Ellipsoid("BreastInnerForSkin",48*mm,58*mm,33*mm);
   auto*skinSolid=new G4SubtractionSolid("SkinShell",outer,innerForSkin);
   s.skin=new G4LogicalVolume(skinSolid,s.skinMat,"Skin");
   new G4PVPlacement(nullptr,{0,0,35*mm},s.skin,"Skin",worldLV,false,0);
   auto*adiposeOuter=new G4Ellipsoid("AdiposeOuter",48*mm,58*mm,33*mm);
   auto*adiposeInner=new G4Ellipsoid("AdiposeInner",44*mm,54*mm,31*mm);
   auto*adiposeShell=new G4SubtractionSolid("AdiposeShell",adiposeOuter,adiposeInner);
   s.adipose=new G4LogicalVolume(adiposeShell,s.adiposeMat,"AdiposeLayer");
   new G4PVPlacement(nullptr,{0,0,35*mm},s.adipose,"AdiposeLayer",worldLV,false,0);
   auto*coreSolid=new G4Ellipsoid("BreastCore",44*mm,54*mm,31*mm);
   s.breast=new G4LogicalVolume(coreSolid,s.breastMat,"BreastCore");
   new G4PVPlacement(nullptr,{0,0,35*mm},s.breast,"BreastCore",worldLV,false,0);
   auto*ts=new G4TessellatedSolid("IrregularTumor");
   for(const auto&t:s.facets)ts->AddFacet(new G4TriangularFacet(t.a,t.b,t.c,ABSOLUTE));
   ts->SetSolidClosed(true);
   s.target=new G4LogicalVolume(ts,s.softMat,"Tumor");
   new G4PVPlacement(nullptr,{0,0,(s.depth-35)*mm},s.target,"Tumor",s.breast,false,0);
   s.wall=new G4LogicalVolume(new G4Box("ChestWall",100*mm,100*mm,15*mm),s.muscleMat,"ChestWall");
   new G4PVPlacement(nullptr,{0,0,85*mm},s.wall,"ChestWall",worldLV,false,0);
   auto lim=new G4UserLimits(s.maxStep*mm);
   s.skin->SetUserLimits(lim);s.adipose->SetUserLimits(lim);s.breast->SetUserLimits(lim);s.target->SetUserLimits(lim);s.wall->SetUserLimits(lim);
   return world;
 }
};
class Physics:public G4VModularPhysicsList{
public:explicit Physics(double cut){SetVerboseLevel(0);defaultCutValue=cut*mm;RegisterPhysics(new G4EmStandardPhysics_option4(0));RegisterPhysics(new G4StepLimiterPhysics());G4EmParameters::Instance()->SetBuildCSDARange(true);}
};
class Gun:public G4VUserPrimaryGeneratorAction{
 G4ParticleGun g{1};
public:Gun(){g.SetParticleDefinition(G4Electron::Definition());g.SetParticleEnergy(6*MeV);g.SetParticleMomentumDirection({0,0,1});}
 void GeneratePrimaries(G4Event*e)override{g.SetParticlePosition({(G4UniformRand()-.5)*60*mm,(G4UniformRand()-.5)*60*mm,-.1*mm});g.GeneratePrimaryVertex(e);}
};
class Events:public G4UserEventAction{State&s;public:explicit Events(State&v):s(v){}void EndOfEventAction(const G4Event*)override{s.finishEvent();}};
class Steps:public G4UserSteppingAction{
 State&s;
public:explicit Steps(State&v):s(v){}
 void UserSteppingAction(const G4Step*st)override{
   auto*pre=st->GetPreStepPoint();auto*post=st->GetPostStepPoint();
   auto*pv=pre->GetPhysicalVolume();auto*qv=post->GetPhysicalVolume();
   auto*pl=pv?pv->GetLogicalVolume():nullptr;auto*ql=qv?qv->GetLogicalVolume():nullptr;
   auto*part=st->GetTrack()->GetDefinition();
   bool charged=part==G4Electron::Definition()||part==G4Positron::Definition();
   bool in=s.body(pl),out=s.body(ql);
   if(pl!=s.target&&ql==s.target&&charged){double en=post->GetKineticEnergy()/MeV;s.eventEntries++;s.eventEntryEnergy+=en;int b=std::min(NH-1,std::max(0,int(en/.05)));s.entryHist[b]++;}
   if(in&&!out){int kind=part==G4Gamma::Definition()?1:(part==G4Positron::Definition()?2:0);double en=post->GetKineticEnergy()/MeV;s.exitCounts[kind]++;s.exitKinetic[kind]+=en;s.eventExit+=en+(kind==2?2*electron_mass_c2/MeV:0.);int b=std::min(NH-1,std::max(0,int(en/.05)));if(kind==1)s.exitPhotonHist[b]++;else s.exitElectronHist[b]++;}
   const double crossingEnergy=post->GetKineticEnergy()/MeV+
       (part==G4Positron::Definition()?2*electron_mass_c2/MeV:0.);
   if(!in&&out)s.eventBodyIn+=crossingEnergy;
   if(post->GetStepStatus()==fWorldBoundary)s.eventWorldOut+=crossingEnergy;
   double e=st->GetTotalEnergyDeposit()/MeV;
   if(!in){s.eventOutsideDeposit+=e;return;}
   s.eventTotal+=e;
   auto mid=.5*(pre->GetPosition()+post->GetPosition());
   if(pl==s.target){s.eventTarget+=e;if(charged)s.eventTrack+=st->GetStepLength()/mm;s.voxelAdd(s.index(mid.x()/mm,mid.y()/mm,mid.z()/mm),e);}
   else if(pl==s.breast)s.eventBreast+=e;
   else if(pl==s.adipose)s.eventAdipose+=e;
   else if(pl==s.skin)s.eventSkin+=e;
   else if(pl==s.wall)s.eventWall+=e;
   if(e>0&&std::abs(mid.x()/mm)<10&&std::abs(mid.y()/mm)<10){int b=int(std::floor(mid.z()/mm/.5));if(b>=0&&b<NB)s.eventDepth[b]+=e;}
 }
};
class Runs:public G4UserRunAction{
 State&s;
public:explicit Runs(State&v):s(v){}
 void EndOfRunAction(const G4Run*r)override{
   long n=r->GetNumberOfEvent();std::ofstream f(s.dir+"/summary.csv");f<<std::setprecision(14)<<"quantity,value,unit\n";
   auto put=[&](std::string key,double x,std::string u){f<<key<<","<<x<<","<<u<<"\n";};
   double targetMass=s.tumorVol*1e-6*s.tumorDensity;
   double breastVolume=4*pi*44*54*31/3.;
   double breastMass=(breastVolume*1e-6*s.breastDensity)-targetMass;
   double adiposeVolume=4*pi*(48*58*33-44*54*31)/3.;
   double adiposeMass=adiposeVolume*1e-6*(s.adiposeMat->GetDensity()/(g/cm3));
   double skinVolume=4*pi*(50*60*35-48*58*33)/3.;
   double skinMass=skinVolume*1e-6*(s.skinMat->GetDensity()/(g/cm3));
   double wallMass=200.*200.*30.*1e-6*(s.muscleMat->GetDensity()/(g/cm3));
   put("histories",n,"primary electrons");put("seed",s.seed,"integer");
   put("tumor_max_diameter_x_mm",s.dx,"mm");put("tumor_width_y_mm",s.dy,"mm");put("tumor_thickness_z_mm",s.dz,"mm");
   put("tumor_center_depth_mm",s.depth,"from anterior skin apex");put("tumor_proximal_depth_mm",s.depth-s.dz/2,"from anterior skin apex");put("tumor_distal_depth_mm",s.depth+s.dz/2,"from anterior skin apex");
   put("tumor_mesh_volume_mm3",s.tumorVol,"mm3");put("tumor_mass_kg",targetMass,"kg");put("tumor_density_g_cm3",s.tumorDensity,"g/cm3");
   put("breast_core_mass_excluding_tumor_kg",breastMass,"kg");put("adipose_shell_mass_kg",adiposeMass,"kg");put("skin_shell_mass_kg",skinMass,"kg");put("chest_wall_mass_kg",wallMass,"kg");
   put("beam_energy",6,"MeV monoenergetic ideal electrons");put("field_size",60,"mm x 60 mm uniform square field");put("max_step_mm",s.maxStep,"mm");put("production_range_cut_mm",s.cut,"mm");
   for(auto pair:{std::pair<const char*,Moment*>{"tumor",&s.targetE},{"breast_core",&s.breastE},{"adipose",&s.adiposeE},{"skin",&s.skinE},{"chest_wall",&s.wallE}}){
     double mass=pair.first==std::string("tumor")?targetMass:(pair.first==std::string("breast_core")?breastMass:(pair.first==std::string("adipose")?adiposeMass:(pair.first==std::string("skin")?skinMass:wallMass)));
     double edep=pair.second->mean(n),edepSE=pair.second->se(n),dose=edep*JPERMEV/mass,doseSE=edepSE*JPERMEV/mass;
     put(std::string(pair.first)+"_edep_MeV_per_primary",edep,"MeV/primary");put(std::string(pair.first)+"_edep_SD",pair.second->sd(n),"MeV/primary");put(std::string(pair.first)+"_edep_SE",edepSE,"MeV/primary");put(std::string(pair.first)+"_dose_Gy_per_primary",dose,"Gy/primary");put(std::string(pair.first)+"_dose_SD_Gy_per_primary",pair.second->sd(n)*JPERMEV/mass,"Gy/primary");put(std::string(pair.first)+"_dose_SE_Gy_per_primary",doseSE,"Gy/primary");put(std::string(pair.first)+"_dose_relative_SE_percent",100*doseSE/dose,"percent");put(std::string(pair.first)+"_primaries_per_1Gy",1./dose,"primary electrons");
   }
   put("tumor_charged_track_length_per_primary",s.trackLength.mean(n),"mm/primary");
   put("tumor_charged_track_length_SE",s.trackLength.se(n),"mm/primary");
   put("tumor_charged_surface_entries_per_primary",s.entryCount.mean(n),"crossings/primary");
   put("mean_charged_entry_kinetic_energy_MeV",s.entryEnergy.sum/s.entryCount.sum,"MeV");
   put("body_edep_MeV_per_primary",s.totalE.mean(n),"MeV/primary");
   put("body_inward_energy",s.bodyInE.mean(n),"MeV/primary");
   put("body_outward_energy",s.exitE.mean(n),"MeV/primary");
   put("body_boundary_residual",s.bodyResidualE.mean(n),"MeV/primary");
   put("body_boundary_residual_SE",s.bodyResidualE.se(n),"MeV/primary");
   put("world_outward_energy",s.worldOutE.mean(n),"MeV/primary");
   put("outside_body_deposited_energy",s.outsideDepositE.mean(n),"MeV/primary");
   put("world_residual",s.worldResidualE.mean(n),"MeV/primary");
   put("world_residual_SE",s.worldResidualE.se(n),"MeV/primary");
   put("tumor_fraction_of_body_deposition",s.targetE.mean(n)/s.totalE.mean(n),"fraction");
   put("target_voxel_pitch_mm",s.voxelPitch,"mm; voxel map is exploratory, not DVH-validated");
   double voxelMass=0;for(auto&v:s.voxels)voxelMass+=v.fraction*std::pow(s.voxelPitch,3)*1e-6*s.tumorDensity;
   put("voxel_mass_kg",voxelMass,"kg");put("voxel_mass_relative_error",voxelMass/targetMass-1,"fraction");
   std::ofstream depth(s.dir+"/depth_dose.csv");depth<<std::setprecision(14)<<"depth_mm,central_axis_dose_Gy_per_primary,MC_SE_Gy_per_primary,scoring_mass_kg\n";
   for(int i=0;i<NB;i++){double mass=s.depthMass[i];depth<<(i+.5)*.5<<","<<(mass>0?s.depthE[i].mean(n)*JPERMEV/mass:0)<<","<<(mass>0?s.depthE[i].se(n)*JPERMEV/mass:0)<<","<<mass<<"\n";}
   std::ofstream vox(s.dir+"/tumor_voxels.csv");vox<<std::setprecision(12)<<"x_mm,y_mm,z_mm_global,mass_kg,dose_Gy_per_primary,MC_SE_Gy_per_primary\n";
   for(auto&v:s.voxels)if(v.fraction>0){double mass=v.fraction*std::pow(s.voxelPitch,3)*1e-6*s.tumorDensity;vox<<v.x<<","<<v.y<<","<<v.z<<","<<mass<<","<<v.e.mean(n)*JPERMEV/mass<<","<<v.e.se(n)*JPERMEV/mass<<"\n";}
   std::ofstream stl(s.dir+"/irregular_tumor_mesh.stl");stl<<"solid lobulated_ellipsoid_tumor\n"<<std::setprecision(8);
   for(const auto&t:s.facets){auto normal=(t.b-t.a).cross(t.c-t.a).unit();stl<<" facet normal "<<normal.x()<<" "<<normal.y()<<" "<<normal.z()<<"\n  outer loop\n";for(const auto&p:{t.a,t.b,t.c})stl<<"   vertex "<<p.x()<<" "<<p.y()<<" "<<p.z()<<"\n";stl<<"  endloop\n endfacet\n";}
   stl<<"endsolid lobulated_ellipsoid_tumor\n";
   std::ofstream spec(s.dir+"/spectra.csv");spec<<"energy_low_MeV,energy_high_MeV,tumor_charged_entry_crossings_per_primary,body_electron_exit_crossings_per_primary,body_photon_exit_crossings_per_primary\n";
   for(int i=0;i<NH;i++)spec<<i*.05<<","<<(i+1)*.05<<","<<s.entryHist[i]/n<<","<<s.exitElectronHist[i]/n<<","<<s.exitPhotonHist[i]/n<<"\n";
   std::ofstream mat(s.dir+"/material_physics.csv");mat<<std::setprecision(12)<<"material,density_g_cm3,energy_MeV,electronic_stopping_MeV_per_mm,total_stopping_MeV_per_mm,CSDA_range_mm,hard_ionisation_inverse_mm_above_10keV,hard_brems_inverse_mm_above_10keV\n";
   G4EmCalculator c;
   // Use the material-pointer overload for CSDA range. The string overload
   // defaults to a region literally named "world", but Geant4 assigns the
   // world logical volume to DefaultRegionForTheWorld. The old call therefore
   // emitted one benign G4RegionStore warning per material/energy query while
   // writing this auxiliary table; it did not configure transport production cuts.
   for(auto* m:{s.skinMat,s.adiposeMat,s.softMat,s.breastMat,s.muscleMat})for(double en:{.1,.25,.5,1.,2.,3.,4.,5.,6.})mat<<m->GetName()<<","<<m->GetDensity()/(g/cm3)<<","<<en<<","<<c.ComputeElectronicDEDX(en*MeV,"e-",m->GetName())/(MeV/mm)<<","<<c.ComputeTotalDEDX(en*MeV,"e-",m->GetName())/(MeV/mm)<<","<<c.GetCSDARange(en*MeV,G4Electron::Definition(),m,nullptr)/mm<<","<<c.ComputeCrossSectionPerVolume(en*MeV,G4Electron::Definition(),"eIoni",m,.01*MeV)*mm<<","<<c.ComputeCrossSectionPerVolume(en*MeV,G4Electron::Definition(),"eBrem",m,.01*MeV)*mm<<"\n";
   std::ofstream materials(s.dir+"/materials.csv");materials<<"model_region,material,density_g_cm3,definition\n";
   materials<<"skin,G4_SKIN_ICRP,"<<s.skinMat->GetDensity()/(g/cm3)<<",2-mm shell from ICRP/NIST data\n";
   materials<<"adipose_layer,G4_ADIPOSE_TISSUE_ICRP,"<<s.adiposeMat->GetDensity()/(g/cm3)<<",nested adipose shell\n";
   materials<<"soft_tissue_component,G4_TISSUE_SOFT_ICRP,"<<s.softMat->GetDensity()/(g/cm3)<<",60-percent mass fraction in breast surrogate and tumor material\n";
   materials<<"breast_core,BreastMix_40Adipose_60Soft,"<<s.breastDensity<<",nested core mixture surrogate; not patient-specific\n";
   materials<<"tumor,G4_TISSUE_SOFT_ICRP,"<<s.tumorDensity<<",soft-tissue proxy; biological tumor composition not measured\n";
   materials<<"chest_wall,G4_MUSCLE_SKELETAL_ICRP,"<<s.muscleMat->GetDensity()/(g/cm3)<<",30-mm slab posterior to breast\n";
   std::cout<<"FINISHED N="<<n<<" target_Gy_per_primary="<<s.targetE.mean(n)*JPERMEV/targetMass<<" target_relSE="<<100*s.targetE.se(n)/s.targetE.mean(n)<<" body_edep_MeV_per_primary="<<s.totalE.mean(n)<<std::endl;
 }
};
int main(int argc,char**argv){
 if(argc!=8&&argc!=9){std::cerr<<"usage: irregular_tumor diameter_mm center_depth_mm histories seed max_step_mm cut_mm output_dir [voxel_pitch_mm]\n";return 1;}
 const double voxelPitch=(argc==9)?std::stod(argv[8]):2.0;
 if(voxelPitch<=0){std::cerr<<"voxel_pitch_mm must be positive\n";return 1;}
 State s(std::stod(argv[1]),std::stod(argv[2]),std::stoi(argv[3]),std::stoi(argv[4]),std::stod(argv[5]),std::stod(argv[6]),argv[7],voxelPitch);
 G4Random::setTheSeed(s.seed);
 auto*rm=new G4RunManager;rm->SetUserInitialization(new Detector(s));rm->SetUserInitialization(new Physics(s.cut));
 rm->SetUserAction(new Gun);rm->SetUserAction(new Events(s));rm->SetUserAction(new Steps(s));rm->SetUserAction(new Runs(s));
 auto*ui=G4UImanager::GetUIpointer();ui->ApplyCommand("/run/verbose 0");ui->ApplyCommand("/event/verbose 0");ui->ApplyCommand("/tracking/verbose 0");
 rm->Initialize();rm->BeamOn(s.events);delete rm;return 0;
}

