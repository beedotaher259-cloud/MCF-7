import csv, os, subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root=Path(__file__).resolve().parent
exe=root/"build/irregular_tumor.exe"
env=os.environ.copy()
env["PATH"]=r"C:\Program Files (x86)\Geant4\bin"+os.pathsep+env.get("PATH","")
data=Path(r"C:\geant4\install\share\Geant4\data")
for key,folder in {"G4LEDATA":"G4EMLOW8.8","G4ENSDFSTATEDATA":"G4ENSDFSTATE3.0","G4LEVELGAMMADATA":"PhotonEvaporation6.1.2","G4PARTICLEXSDATA":"G4PARTICLEXS4.2"}.items():
    env[key]=str(data/folder)
cases=[(d,ref,depth) for d in (25,30) for ref in ("center","surface") for depth in (15,20)]
def run(item):
    i,(d,ref,depth)=item
    tag=f"D{d}_{ref}{depth}"
    dst=root/"retry_runs"/tag
    dst.mkdir(parents=True,exist_ok=True)
    center=depth+(d/3 if ref=="surface" else 0)
    with (dst/"run.log").open("w") as log:
        subprocess.run([str(exe),str(d),str(center),"5000",str(798100+i),"0.2","0.01",str(dst),"2"],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
    with (dst/"summary.csv").open() as f:
        v={r["quantity"]:float(r["value"]) for r in csv.DictReader(f)}
    cols=["histories","tumor_dose_Gy_per_primary","tumor_dose_SE_Gy_per_primary","body_edep_MeV_per_primary","body_inward_energy","body_outward_energy","body_boundary_residual","body_boundary_residual_SE","world_outward_energy","outside_body_deposited_energy","world_residual","world_residual_SE"]
    assert v["histories"]==5000
    print(tag,v["body_boundary_residual"],v["world_residual"],flush=True)
    return {"scenario":tag,**{k:v[k] for k in cols},"net_body_out_MeV_per_primary":v["body_outward_energy"]-(v["body_inward_energy"]-6)}
with ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(run,list(enumerate(cases))[4:5]))
with (root/"retry_energy_audit.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


