import csv, io, itertools, base64, html, zipfile
from pathlib import Path
import numpy as np
from scipy.stats import t
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

source=Path(__file__).with_name("latest_sources_tidy.csv")
if source.is_file():
    out=source.parent/"recreated"
    out.mkdir(exist_ok=True)
    raw=source.read_bytes()
else:
    out=Path("outputs")
    with zipfile.ZipFile(out/"MCF7_MCF10A_Original_Source_Results.zip") as z:
        raw=z.read("03_Experimental/Audit_and_Summary/latest_sources_tidy.csv")
rows=list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
lines=["MCF-7","MCF-10A"]
doses=np.array([0,2.5,5,10,15,20,25])
times=np.array([6,24,48,72])
runs=sorted({r["Run"] for r in rows})
keys={(r["CellLine"],r["Run"],float(r["Dose (Gy)"]),int(r["Time (h)"])):r for r in rows}
assert len(keys)==len(rows)==336 and len(runs)==6
ends=list(rows[0])[4:]
ends.remove("IKATP_provenance")
core=["DeltaPsi_mV","DeltaVm_mV","Zeta_mV","ROS_Fold","ATP_RU","OCR_pmol_min"]
effects=[]; desc=[]; paired=[]; matrices={}
signs=np.array(list(itertools.product([-1,1],repeat=6)))
crit=t.ppf(.975,5)

def estimate(x):
    mean=float(np.mean(x)); sd=float(np.std(x,ddof=1))
    se=sd/np.sqrt(6); half=crit*se
    p=float(2*t.sf(abs(mean/se),5)) if se>1e-12 else None
    loocv=[float(np.delete(x,i).mean()) for i in range(6)]
    return dict(n=6,mean=mean,SD=sd,CI95_low=mean-half,CI95_high=mean+half,
                positive=int(sum(x>1e-10)),negative=int(sum(x< -1e-10)),
                leave_one_out_min=min(loocv),leave_one_out_max=max(loocv),
                exact_p=float(np.mean(abs(signs@x)>=abs(sum(x))-1e-10)),t_p=p)

def adjust(group,col):
    ordered=sorted((r for r in group if r[col] is not None),key=lambda r:r[col])
    worst=0
    for i,r in enumerate(ordered):
        worst=max(worst,min(1,(len(group)-i)*r[col]))
        r[col+"_Holm"]=worst

def slope_weights(x):
    v=x-x.mean()
    return v/(v@v)
wd=slope_weights(doses/10); wt=slope_weights(times/24)
for line in lines:
    for e in ends:
        vals=[keys[line,r,d,h][e] for r in runs for d in doses for h in times]
        if not any(vals): continue
        assert all(vals),(line,e)
        a=np.array(vals,dtype=float).reshape(6,7,4)
        assert np.isfinite(a).all()
        matrices[line,e]=a
        for j,d in enumerate(doses):
            for k,h in enumerate(times):
                meta=dict(cell_line=line,endpoint=e,dose_Gy=d,time_h=h)
                v=a[:,j,k]; st=estimate(v)
                desc.append(meta|{k:st[k] for k in ("n","mean","SD","CI95_low","CI95_high")}|dict(median=np.median(v),min=min(v),max=max(v),zeros=int(sum(v==0))))
                if j: paired.append(meta|estimate(v-a[:,0,k]))
        dl=np.einsum("rdt,d->rt",a,wd)
        contrasts={"dose_per_10Gy":dl.mean(1),
                   "time_per_24h":np.einsum("rdt,t->rd",a,wt).mean(1),
                   "dose_time_interaction":dl@wt}
        for name,x in contrasts.items():
            effects.append(dict(cell_line=line,endpoint=e,contrast=name,
                                family="shared" if e in core else "line_specific")|estimate(x))
for group in ([r for r in effects if r["family"]==f] for f in ["shared","line_specific"]):
    adjust(group,"exact_p"); adjust(group,"t_p")
adjust(paired,"exact_p"); adjust(paired,"t_p")
assert len(effects)==54 and len(desc)==504 and len(paired)==432
assert all(r["exact_p_Holm"]>=r["exact_p"] for r in effects+paired)

def table(rs,fields,heads=None):
    def fmt(v):
        return f"{v:.4g}" if isinstance(v,(float,np.floating)) else ("—" if v is None else str(v))
    return "<table><thead><tr>"+"".join(f"<th>{html.escape(h)}</th>" for h in (heads or fields))+"</tr></thead><tbody>"+ "".join("<tr>"+"".join(f"<td dir='auto'>{html.escape(fmt(r.get(k)))}</td>" for k in fields)+"</tr>" for r in rs)+"</tbody></table>"

def plot(line,end):
    a=matrices[line,end]
    fig,ax=plt.subplots(figsize=(5,3))
    for j,h in enumerate(times):
        ax.errorbar(doses,a.mean(0)[:,j],yerr=a.std(0,ddof=1)[:,j],marker="o",ms=3,capsize=2,label=f"{h} h")
    ax.set(xlabel="Nominal dose (Gy)",ylabel=end,title=line+"   "+end)
    ax.legend(frameon=False,ncols=2,fontsize=8)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y",alpha=.18)
    fig.tight_layout()
    f=io.BytesIO(); fig.savefig(f,format="png",dpi=155); plt.close(fig)
    return '<img alt="'+line+' '+end+'" src="data:image/png;base64,'+base64.b64encode(f.getvalue()).decode()+'">'

shared=[r for r in effects if r["family"]=="shared"]
focus=[r for r in paired if r["dose_Gy"]==10 and r["time_h"]==24 and r["endpoint"] in ["DeltaPsi_mV","ROS_Fold","DeltaVm_mV","Zeta_mV"]]
efields=["cell_line","endpoint","contrast","n","mean","CI95_low","CI95_high","positive","negative","exact_p","exact_p_Holm","t_p_Holm","leave_one_out_min","leave_one_out_max"]
pfields=["cell_line","endpoint","dose_Gy","time_h","n","mean","CI95_low","CI95_high","exact_p","exact_p_Holm"]
dfields=list(desc[0])
n_t=sum(r.get("t_p_Holm",1)<.05 for r in shared)
n_e=sum(r["exact_p_Holm"]<.05 for r in shared)
html_text=f"""<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>تحليل القياسات الخلوية</title>
<style>body{{font:17px/1.7 system-ui,sans-serif;max-width:1130px;margin:32px auto;padding:0 20px;color:#152d3a}}h1,h2{{color:#174e58;line-height:1.3}}table{{width:100%;border-collapse:collapse;font-size:13px;margin:12px 0 26px}}th,td{{border-bottom:1px solid #dbe6e8;padding:6px;text-align:center}}th{{background:#174e58;color:white}}tr:nth-child(even){{background:#f1f6f7}}.figs{{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr))}}img{{width:100%}}details{{margin:20px 0}}summary{{cursor:pointer;font-weight:bold}}@media print{{body{{margin:0}}img,tr{{break-inside:avoid}}}}</style>
<h1>التحليل الإحصائي لاستجابة MCF‑7 وMCF‑10A للإشعاع</h1>
<p>تضم البيانات 336 سجلًا موزعة بالتساوي بين الخطين الخلويين. لكل خط ست جولات تغطي سبع جرعات اسمية من 0 إلى 25 Gy وأربعة أزمنة من 6 إلى 72 ساعة. اجتازت البيانات فحص اكتمال المفاتيح وغياب التكرارات. شمل التحليل 18 زوجًا متاحًا من الخط والمؤشر. حُفظت الأصفار كما سُجلت واستُبعدت المؤشرات غير المقاسة في الخط المعني فقط.</p>
<h2>المقارنة داخل الجولة عند 10 Gy و24 ساعة</h2>
<p>الفرق هو قياس 10 Gy مطروحًا منه ضابط 0 Gy لنفس الجولة والزمن. الفواصل نقطية وغير مصححة للتعدد. هذه المقارنات مختارة للعرض بعد الاطلاع على البيانات.</p>
{table(focus,pfields,['الخط','المؤشر','Gy','ساعة','الجولات','فرق المتوسط','حد 95% الأدنى','حد 95% الأعلى','p الخام','p المعدّلة'])}
<h2>اتجاهات الجرعة والزمن</h2>
<p>حُسبت لكل جولة ثلاثة تباينات خطية. الأول متوسط ميل الجرعة عبر الأزمنة بوحدة المؤشر لكل 10 Gy. الثاني متوسط ميل الزمن عبر الجرعات لكل 24 ساعة. الثالث مقدار تغير ميل الجرعة لكل 24 ساعة. يُلخّص الميل الاتجاه في المجال المدروس، وتعرض الرسوم أي انحناء أو اقتراب من حدود القياس. في التحليل الرئيسي جُمعت 36 مقارنة عبر المؤشرات الستة المشتركة والخطين. وتضم العائلة الاستكشافية 18 مقارنة للمؤشرات الخاصة بخط واحد.</p>
<p>بعد تصحيح Holm، اجتاز <b>{n_e} من 36</b> اختبارًا رئيسيًا حد 0.05 في اختبار تبديل الإشارة، مقابل <b>{n_t} من 36</b> في تحليل الحساسية باختبار t. مع ست جولات يكون أصغر p ثنائي في تبديل الإشارة 0.03125، ولذلك قدرة الاختبار المصحح على الكشف محدودة جدًا بهذا التصميم. نتيجة الحساسية تعتمد على استقلال الجولات وتقريب التوزيع الطبيعي لتباينات الجولة، وهي افتراضات يصعب تقييمها بست جولات. تُقرأ الفروق وفواصلها واتساق الاتجاه عبر الجولات معًا.</p>
<p>افتُرض أن رقم الجولة يربط الشروط داخل الخط وأن الجولات مستقلة. اختُبرت جميع تبديلات الإشارة الـ64 باستخدام القيمة المطلقة لمجموع التباينات. يتطلب التفسير الاستدلالي تماثل توزيع التباينات حول الصفر تحت فرض العدم. أُجري فحص حذف جولة واحدة في كل مرة. الأرقام المتطابقة للجولات بين الخطين لا تكفي لإثبات الاقتران بينهما، لذا تعرض الرسوم والملخصات الفروق بين الخطين وصفيًا.</p>
<h2>منحنيات الجرعة حسب زمن القياس</h2><p>كل نقطة متوسط ست جولات، والأشرطة ± انحراف معياري واحد بين الجولات.</p>
<div class="figs">{''.join(plot(l,e) for e in ['DeltaPsi_mV','ROS_Fold','DeltaVm_mV','Zeta_mV'] for l in lines)}</div>
<details open><summary>النتائج الكاملة لاختبارات الاتجاه</summary><p>حدا CI لفاصل t نقطي 95%. موجب وسالب يبيّنان عدد الجولات في كل اتجاه. عمودا حذف جولة يعرضان أصغر وأكبر تقدير بعد حذف جولة واحدة.</p>
{table(effects,efields,['الخط','المؤشر','التباين','n','الأثر','CI أدنى','CI أعلى','موجب','سالب','p خام','Holm','t Holm','حذف أدنى','حذف أعلى'])}</details>
<details><summary>المقارنات الـ432 مع الضابط المطابق</summary>{table(paired,pfields)}</details>
<details><summary>الملخصات الوصفية الـ504 لجميع الشروط</summary>{table(desc,dfields)}</details>
<p>التحليل استكشافي لأن اختيار التباينات جاء بعد مراجعة النتائج، ولأن استقلال الجولات وتعريف وحدة التكرار يعتمدان على سجل التجربة. I_KATP غير مقاس في MCF‑10A. المقارنات مع الضابط عائلة استكشافية منفصلة من 432 اختبارًا. قيم p المعدّلة وفواصل الثقة النقطية تجيب عن أسئلة مختلفة. <a href="https://doi.org/10.1016/j.neuroimage.2014.01.060">مرجع تبديل الإشارة</a>.</p></html>"""
(out/"MCF_Cell_Statistics_AR.html").write_text(html_text,encoding="utf-8")
with zipfile.ZipFile(out/"MCF_Statistics_Reproducibility.zip","w",zipfile.ZIP_DEFLATED) as z:
    z.writestr("latest_sources_tidy.csv",raw)
    for name,data in [("round_level_contrasts.csv",effects),("paired_vs_control.csv",paired),("descriptive_summary.csv",desc)]:
        fp=io.StringIO()
        fields=list(dict.fromkeys(k for row in data for k in row))
        writer=csv.DictWriter(fp,fieldnames=fields); writer.writeheader();writer.writerows(data)
        z.writestr(name,fp.getvalue().encode("utf-8-sig"))
    z.write(Path(__file__), "analyze.py")
print("shared exact/t Holm",n_e,n_t)
for r in focus: print(r["cell_line"],r["endpoint"],r["mean"],r["CI95_low"],r["CI95_high"],r["exact_p"])

